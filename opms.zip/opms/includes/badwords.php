<?php


$badwords = array(
    "hell",
    "bastard",
    "idiot",
	"fuck",
    "nonsense"
);

$wordreplace = array(
    "!",
    "@",
    "",
    "%",
    "^",
    "&",
    "*",
    "~"
);

/*
#############################################################
## C O D E (DO NOT EDIT BELOW THIS LINE)		   ##
############################################################# */

class badword
{
    function word_fliter($content)
    {
        global $badwords, $wordreplace;
        $count = count($badwords);
        $countfilter = count($wordreplace) - 1;
        // Loop through the badwords array
        for ($n = 0; $n < $count; ++$n, next($badwords)) {
            //Create random replace characters
            $x = 2;
            $y = rand(3, 5);
            $filter = "";
            while ($x <= "$y") {
                $f = rand(0, $countfilter);
                $filter .= "$wordreplace[$f]";
                $x++;
            }

            //Search for badwords in content

            $search = "$badwords[$n]";
            $content = preg_replace("'$search'i", "<i>$filter</i>", $content);

        }
        return $content;
    }
}

?>
		
