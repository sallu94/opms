<?php
/**
 * Created by PhpStorm.
 * User: Salman
 * Date: 28-02-2017
 * Time: 11:01 00 PM
 */
$WEBSITE_NAME="Online Training Management System";
$TAGLINE="";

define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "project");


?>