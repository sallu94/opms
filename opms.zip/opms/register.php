<?php session_start(); ?>
<!DOCTYPE html>
<html lang="eng">
<head>

    <title>Online Training and Placement Management System | Register</title>
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all">
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
	<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
	<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&subset=latin-ext,vietnamese" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900iSource+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
	<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>

		<script src="js/jquery.chocolat.js"></script>
		<link rel="stylesheet" href="css/chocolat.css" type="text/css" media="screen">
		<!--light-box-files -->
		<script>
		$(function() {
			$('.gallery-grid a').Chocolat();
		});
		</script>

<!-- //js -->
<script src="js/responsiveslides.min.js"></script>
		<script>
				$(function () {
					$("#slider").responsiveSlides({
						auto: true,
						pager:false,
						nav: true,
						speed: 1000,
						namespace: "callbacks",
						before: function () {
							$('.events').append("<li>before event fired.</li>");
						},
						after: function () {
							$('.events').append("<li>after event fired.</li>");
						}
					});
				});
			</script>
			

<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->



</head>
<body>
<div class="header" id="home">
	<div class="logo">
		<a href="index.html"><h1>Placement Cell </h1></a>
	</div>
<!-- navigation -->
		<div class="ban-top-con">
			<div class="top_nav_left">
				<nav class="navbar navbar-default">
				  <div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
					</div>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse menu--shylock" id="bs-example-navbar-collapse-1">
					  <ul class="nav navbar-nav menu__list">
						<li class="active menu__item menu__item"><a class="menu__link scroll" href="index.html">Home</a></li>
						<li class="dropdown">
                        <a class="menu__link scroll" href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                           aria-haspopup="true" aria-expanded="false">Log in <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="admin/index.php">Admin</a></li>
							<li><a href="leader/index.php">Faculty</a></li>
                            <li><a href="users/login.php">Student</a></li>
							<li><a href="../register.php">New Account?</a></li>
                        </ul>
                    </li>
					  </ul>
					</div>
				  </div>
				</nav>	
				
			</div>
			<div class="clearfix"></div>
			</div>
			
			<div class="team" id="management">
	<div class="container"><br/><br/><br/>
	 
		<h3>Registration</h3>
		<p>New User? Get Registered and access the placement training in fraction of seconds.</p>
		<div class="container">
                <hr/>
				<div class="OurLove-grids">
            <div class="col-md-5 OurLove-grid">
                <img src="images/banner3.png" class="img-responsive img-circle"/>
            </div>
                <form class="form-horizontal" method="post" action="">
                    <div class="col-sm-6">
					<input type="text" name="full_name" placeholder="Full Name" class="form-control" required/><br/>
					<input type="email" name="email" placeholder="Email" class="form-control"required/><br/>
                    <input type="text" name="username" placeholder="Username" class="form-control"required/><br/>
                    <input type="password" name="password" placeholder="Password" class="form-control"required/><br/>
                    <input type="password" name="confirm_password" placeholder="Confirm Password" class="form-control"required/><br/>
                    <input type="date" class="form-control" name="bday" max="2000-01-01"/><br/>
                    <select name="gender" class="form-control">
                        <option class="label label-info">---Select Gender---</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select><br/>
                    <input type="submit" value="Become a member" class="btn btn-primary" name="signup"/><br/>
					
                </form>

                <a href="users/login.php">I am already a member.</a>
				</div>
                <?php
                if (isset($_POST['signup'])) {
                    include_once("includes/database_function.php");
                    connect();

                    $full_name = $_POST['full_name'];
                    $username = $_POST['username'];
                    $password = $_POST['password'];
                    $bday = $_POST['bday'];
                    $gender = $_POST['gender'];

                    $q = "INSERT INTO users (full_name,username,password,birth_date,gender) VALUES ('$full_name','$username','$password','$bday','$gender');";
                    mysql_query($q) or die(mysql_error());


                    echo '<script>alert("Successfully Registered"); location.href="users/login.php";</script>';
                }
                ?>
            </div>
			
		</div>
	</div>
		<div class="clearfix"></div>
	</div>
</div>

<!--footer-->
<div class="w3l-footer">
	<div class="container">
		<div class="left-w3">
			<a href="#">Placement Cell</a>
		</div>
		<div class="right-social">
			<i class="fa fa-facebook-square" aria-hidden="true"></i>
			<i class="fa fa-twitter-square" aria-hidden="true"></i>
			<i class="fa fa-google-plus-square" aria-hidden="true"></i>
		</div>
		<div class="clearfix"></div>
		<div class="footer-nav">
			<ul>
				<li><a class="menu__link scroll" href="#home">home</a></li>
				<li><a class="menu__link scroll" href="#about">about</a></li>
				<li><a class="menu__link scroll" href="#management">management</a></li>
				<li><a class="menu__link scroll" href="#activities">activities</a></li>
				<li><a class="menu__link scroll" href="#faculties">faculties</a></li>
				<li><a class="menu__link scroll" href="#contact">contact</a></li>
				<li><a href="register.php">Register</a></li>
			</ul>
		</div>
		<div class="copyright-agile">
			<p>&copy; 2017 Placement Cell. All rights reserved | Design by <a href="http://www.jainbgm.in">JCE</a></p>
		</div>
	</div>
</div>
<!--//footer-->
<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //smooth scrolling -->
</body>
</html>