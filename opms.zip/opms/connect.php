<?php

$user = 'root';
$pass = '';
$db = 'project';

$db = new mysqli('localhost', $user, $pass, $db); or die("Unable to Connect, Please try again..");

echo"Great Work!!!";

?>