<!DOCTYPE html>
<html lang="en">
<head>
<title>Online Placement and Training Management System | Home </title>
<!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Online Placement and Training Management System, Jain College of Engineering, Belgaum, belagavi, karnataka, India, Placement, Online Training, Smartphone, Andriod" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Meta tag Keywords -->
<!-- css files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all">
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
<!-- //css files -->
<!-- online-fonts -->
<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&subset=latin-ext,vietnamese" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900iSource+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i&subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>

		<script src="js/jquery.chocolat.js"></script>
		<link rel="stylesheet" href="css/chocolat.css" type="text/css" media="screen">
		<!--light-box-files -->
		<script>
		$(function() {
			$('.gallery-grid a').Chocolat();
		});
		</script>

<!-- //js -->
<script src="js/responsiveslides.min.js"></script>
		<script>
				$(function () {
					$("#slider").responsiveSlides({
						auto: true,
						pager:false,
						nav: true,
						speed: 1000,
						namespace: "callbacks",
						before: function () {
							$('.events').append("<li>before event fired.</li>");
						},
						after: function () {
							$('.events').append("<li>after event fired.</li>");
						}
					});
				});
			</script>
			

<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->

</head>
<body>
<!--header-->

<div class="container">
    <div class="content">
        <div class="wedding-section">
            <div class="container">
                <br/><br/><br/><center><h2>Placement Cell Gallery</h2><br/><br/>
                <hr/>
                <?php
                include_once "./includes/database_function.php";
                connect();

                $rs = getTableData("gallery");
                $count = 1;
                while ($gallery = mysql_fetch_array($rs)) {

                    ?>
                    <div class="gallery-grids">
                        <div class="col-md-3 gallery-grid">
                            <div class="gallery-grd">

                                <a class="swipebox" href="<?php echo './' . $gallery['img_path']; ?>">
                                    <span class="label label-success"><?php echo $gallery['img_name']; ?></span> <br
                                        /><br/>
                                    <img src="<?php echo './' . $gallery['img_path']; ?>"
                                         class="img-circle img-responsive"/>
                                    <br/>
                                    <span class="label label-info"><?php echo $gallery['img_desc']; ?></span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <?php
                } ?>

            </div>
        </div>

    </div>

</div>

<!--footer-->
<div class="w3l-footer">
	<div class="container">
		<div class="left-w3">
			<a href="#">Placement Cell</a>
		</div>
		<div class="right-social">
			<i class="fa fa-facebook-square" aria-hidden="true"></i>
			<i class="fa fa-twitter-square" aria-hidden="true"></i>
			<i class="fa fa-google-plus-square" aria-hidden="true"></i>
		</div>
		<div class="clearfix"></div>
		<div class="footer-nav">
			<ul>
				<li><a class="menu__link scroll" href="#home">home</a></li>
				<li><a class="menu__link scroll" href="#about">about</a></li>
				<li><a class="menu__link scroll" href="#management">management</a></li>
				<li><a class="menu__link scroll" href="#activities">activities</a></li>
				<li><a class="menu__link scroll" href="#faculties">faculties</a></li>
				<li><a class="menu__link scroll" href="#contact">contact</a></li>
				<li><a href="register.php">Register</a></li>
			</ul>
		</div>
		<div class="copyright-agile">
			<p>&copy; 2017 Placement Cell. All rights reserved | Design by <a href="http://www.jainbgm.in">JCE</a></p>
		</div>
	</div>
</div>
<!--//footer-->
<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //smooth scrolling -->
</body>
</html>