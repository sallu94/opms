-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 14, 2016 at 04:18 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------
-- Table structure for table `area`
--

CREATE TABLE IF NOT EXISTS `area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `area_name` varchar(255) NOT NULL,
  `leader` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `map_url` varchar(10000) NOT NULL DEFAULT 'https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d30702.795876617496!2d74.50012379812715!3d15.864506224176605!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1smedical+stores+nearby+belgaum!5e0!3m2!1sen!2sin!4v1460194543384',
  PRIMARY KEY (`id`),
  UNIQUE KEY `area_name` (`area_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`id`, `area_name`, `leader`, `location`, `map_url`) VALUES
(1, 'Tilakwadi', 'dsp', 'north', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15353.463566269025!2d74.49113362077657!3d15.83735536765144!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bbf6683d3d61bf1%3A0xdfd57941bde604fb!2sTilakwadi%2C+Belagavi%2C+Karnataka!5e0!3m2!1sen!2sin!4v1463042907754'),
(2, 'Hindalga', 'vinuta', 'north', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3837.6823172193117!2d74.47699236438307!3d15.87328559887656!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bbf63f5a1c68b53%3A0xa7e1e22d86c87099!2sHindalga%2C+Belagavi%2C+Karnataka+591108!5e0!3m2!1sen!2sin!4v1463042953794'),
(3, 'RPD', 'vidya', 'north', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3838.417510822046!2d74.50391824216884!3d15.834638915766424!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bbf6683f40e5597%3A0x7d27b90b6cefc7cb!2sRPD+Cross+Bus+Stop!5e0!3m2!1sen!2sin!4v1463042822182'),
(4, 'Ganeshpur', 'harish', 'north', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15351.238165211762!2d74.46356767078197!3d15.866604414368796!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bbf647529440d9b%3A0xe675099c5cfe1f07!2sGaneshpur%2C+Belagavi%2C+Karnataka+591108!5e0!3m2!1sen!2sin!4v1463042996120'),
(6, 'India', 'modi', 'north', 'https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d30702.795876617496!2d74.50012379812715!3d15.864506224176605!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1smedical+stores+nearby+belgaum!5e0!3m2!1sen!2sin!4v1460194543384'),
(7, 'Gandhi Nagar', 'Suraj', 'south', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15351.483533212959!2d74.52745062212333!3d15.86338205394168!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bbf66c48f57c733%3A0xfc6401636f42781!2sGandhi+Nagar%2C+Belagavi%2C+Karnataka!5e0!3m2!1sen!2sin!4v1463043052623'),
(8, 'US', 'firoj', 'north', 'https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d30702.795876617496!2d74.50012379812715!3d15.864506224176605!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1smedical+stores+nearby+belgaum!5e0!3m2!1sen!2sin!4v1460194543384');

-- --------------------------------------------------------

--
-- Table structure for table `chat_discussion`
--

CREATE TABLE IF NOT EXISTS `chat_discussion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_id` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `chat_discussion`
--

INSERT INTO `chat_discussion` (`id`, `topic_id`, `user`, `comment`) VALUES
(1, '6', 'dsp', 'this is something to think on. '),
(2, '6', 'dsp', 'what about poor childs?'),
(3, '6', 'dsp', 'ya correct. This will create discrimination if removed from school.'),
(4, '9', 'dsp', 'Its good to be technically ahead but child are not supposed to use until at a proper age.'),
(5, '9', 'vinuta', 'Ya me too thinking the same. Even if we provide them smart phone, they should be properly guided and told about the misuse of the smart phones.');

-- --------------------------------------------------------

--
-- Table structure for table `chat_topics`
--

CREATE TABLE IF NOT EXISTS `chat_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_title` varchar(250) NOT NULL,
  `topic_desc` varchar(2500) NOT NULL,
  `user` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `chat_topics`
--

INSERT INTO `chat_topics` (`id`, `topic_title`, `topic_desc`, `user`) VALUES
(6, 'Why Uniform ?', 'does uniform plays any role in schools and college? Why don''t govt remove this thing? ', 'dsp'),
(7, 'Right to elect the President.', 'I think our system needs to change a bit. Why don''t the public choose their president instead of the parliament ministers like in USA. ', 'dsp'),
(8, 'Why GOVT rule 5 years and not less or more. Let the public decide.', 'The public should decide the duration of the govt. Public can remove or extends the default 5 years period of govt. ', 'dsp'),
(9, 'Smart Phone Miss Leading Children.', 'Child below 10th std shouldn''t be given smart phone. ', 'dsp');

-- --------------------------------------------------------

--
-- Table structure for table `comment_likes`
--

CREATE TABLE IF NOT EXISTS `comment_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problem_id` varchar(255) NOT NULL,
  `user` varchar(250) NOT NULL,
  `user_like` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `comment_likes`
--

INSERT INTO `comment_likes` (`id`, `problem_id`, `user`, `user_like`) VALUES
(3, '1', 'dsp', 'yes'),
(4, '1', 'jack', 'yes'),
(5, '2', 'jack', 'yes'),
(6, '4', 'jack', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img_name` varchar(250) NOT NULL,
  `img_path` varchar(250) NOT NULL,
  `img_desc` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `img_name`, `img_path`, `img_desc`) VALUES
(4, 'swarn', 'gallery_img/swarn.jpg', 'swarn sudha belgaum bangalore road.'),
(5, 'railway', 'gallery_img/railway.jpg', 'belgaum railway station board on platform. '),
(6, 'MyBgm', 'gallery_img/MyBgm.jpg', 'SmartBGM get refreshed');

-- --------------------------------------------------------

--
-- Table structure for table `leader`
--

CREATE TABLE IF NOT EXISTS `leader` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `leader`
--

INSERT INTO `leader` (`id`, `full_name`, `username`, `password`) VALUES
(2, 'Dalpat Singh', 'dsp', 'dsp'),
(3, 'Vinuta', 'vinuta', 'vinuta'),
(4, 'Harish', 'harish', 'harish'),
(6, 'Narendra Modi', 'modi', 'modi'),
(7, 'Suraj', 'Suraj', 'Suraj'),
(8, 'Obama', 'obama', 'obama'),
(9, 'Firoj Seth', 'firoj', 'firoj'),
(10, 'vidya', 'vidya', 'vidya');

-- --------------------------------------------------------

--
-- Table structure for table `leader_review`
--

CREATE TABLE IF NOT EXISTS `leader_review` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leader_id` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `review` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `leader_review`
--

INSERT INTO `leader_review` (`id`, `leader_id`, `user`, `review`) VALUES
(3, '2', 'dsp', 'one vote from me '),
(4, '3', 'dsp', 'working well. +1 for this');

-- --------------------------------------------------------

--
-- Table structure for table `leader_vote`
--

CREATE TABLE IF NOT EXISTS `leader_vote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leader_id` varchar(255) NOT NULL,
  `user` varchar(250) NOT NULL,
  `user_vote` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `leader_vote`
--

INSERT INTO `leader_vote` (`id`, `leader_id`, `user`, `user_vote`) VALUES
(6, '2', 'dsp', 'yes'),
(5, '3', 'dsp', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `problem`
--

CREATE TABLE IF NOT EXISTS `problem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `area` varchar(255) NOT NULL,
  `user` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `img_path` varchar(1000) NOT NULL,
  `progress` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `problem`
--

INSERT INTO `problem` (`id`, `title`, `description`, `area`, `user`, `status`, `img_path`, `progress`) VALUES
(1, 'Health Problem in City', 'Rapidly new illness is getting spread in the city. Govt needs to take some serious action.', 'Tilakwadi', 'dsp', 'Work In Progress', 'users_images/helo.jpg', 10),
(2, 'Water Problem', 'Due to insufficient rain in area. Govt is cutting of water in area. We understand that but completely shutting down water supply is a shame on govt. Are you listening ???', 'Shahapur', 'dsp', 'Work In Progress', 'users_images/road.jpg', 50),
(5, 'No vacations', 'Continuous exams and no vacations.', 'Gandhi Nagar', 'dsp', 'Work In Progress', 'users_images/helo.jpg', 40),
(3, 'Power cut Problem', 'No power from 10 days', 'Shahapur', 'dsp', 'Work In Progress', 'users_images/road.jpg', 20),
(4, 'problem in south', 'Gandhi Nagar is facing flood where as rest of belgaum is waiting for rain :p', 'Gandhi Nagar', 'dsp', 'Work In Progress', 'users_images/helo.jpg', 30),
(6, 'Garbage problem', 'Everywhere there is garbage on the road. Please clean the city.\r\n', 'Ganeshpur', 'dsp', 'completed', 'users_images/helo.jpg', 100),
(7, 'Basic Problem', 'Issue ', 'Tilakwadi', 'dsp', 'Work In Progress', 'users_images/helo.jpg', 70),
(8, 'Road Problem', 'Problem', 'RPD', 'dsp', 'Work In Progress', 'users_images/Screenshot (1).png', 70),
(9, 'new proq', 'is it posting', 'Tilakwadi', 'dsp', 'rejected', 'users_images/g (11).jpg', 0),
(10, 'Posted by vinuta', 'is it working here? Lets see', 'Tilakwadi', 'vinuta', 'pending', 'users_images/g (12).jpg', 0),
(11, 'Road Construction', 'Road Construction process in RPD is taking too long.', 'RPD', 'dsp', 'pending', 'users_images/g5.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `problem_comments`
--

CREATE TABLE IF NOT EXISTS `problem_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problem_id` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `problem_comments`
--

INSERT INTO `problem_comments` (`id`, `problem_id`, `user`, `comment`) VALUES
(1, '1', 'dsp', 'hi'),
(2, '3', 'dsp', '<i>!*!</i>o'),
(3, '5', 'dsp', 'thankyou'),
(4, '6', 'dsp', 'what <i>*~</i> is this'),
(5, '5', 'dsp', '<i>!!%~</i>'),
(6, '5', 'dsp', 'sdadad'),
(7, '6', 'dsp', 'You are an <i>^~@</i>.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `birth_date` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `username_2` (`username`),
  UNIQUE KEY `username_3` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `username`, `password`, `birth_date`, `gender`) VALUES
(1, 'Dalpat Singh Purohit', 'dsp', 'dsp', '1993-02-24', 'male'),
(2, 'Suraj Koperde', 'suraj', 'suraj', '1992-02-24', 'female'),
(3, 'Vidya', 'vidya', 'vidya', '1993-02-24', 'female'),
(4, 'Vinuta', 'vinuta', 'vinuta', '1994-07-26', 'female'),
(5, 'Jack', 'jack', 'jack', '1993-02-24', 'male'),
(6, 'user', 'user', 'user', '1993-02-24', 'male'),
(7, 'captain', 'sparrow', 'sparrow', '1993-02-24', 'male'),
(8, 'my', 'name', 'name', '1993-02-24', 'male'),
(9, 'dsp', 'hellow', 'world', '1993-02-24', 'male');
