<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Highcharts Example</title>

    <script type="text/javascript" src="js/jquery.min.js"></script>
    <style type="text/css">
        ${demo.css}
    </style>
    <script type="text/javascript">
        $(function () {

            $(document).ready(function () {

                // Build the chart
                $('#container').highcharts({
                    chart: {
                        plotBackgroundColor: null,
                        plotBorderWidth: null,
                        plotShadow: false,
                        type: 'pie'
                    },
                    title: {
                        text: 'Problem Status Chart for Different Areas'
                    },
                    tooltip: {
                        pointFormat: '{series.name}: <b>{point.percentage:0.0f}%</b>'
                    },
                    plotOptions: {
                        pie: {
                            allowPointSelect: false,
                            cursor: 'pointer',
                            dataLabels: {
                                enabled: false
                            },
                            showInLegend: false
                        }
                    },
                    series: [{
                        name: 'Status',
                        colorByPoint: true,


                        data: [
                            <?php
                            include_once "includes/database_function.php";
                            connect();
                            $result = mysql_query("SELECT * FROM problem");
                            while ($row = mysql_fetch_array($result)) { ?>

                            { name: '<?php echo $row['area']; ?>', y: <?php echo $row['id']; ?> },

                            <?php } ?>
                        ]


                    }]
                });
            });
        });
    </script>
</head>
<body>
<script src="js/highcharts.js"></script>
<script src="js/exporting.js"></script>

<div id="container" style="min-width: 310px; height: 400px; max-width: 600px; margin: 0 auto"></div>

</body>
</html>
